

import tensorflow as tf


def special_pooling(net,reduction_ratio=0.5):
    with tf.variable_scope("sp_" , reuse=tf.AUTO_REUSE):
      batch_size=net.get_shape()[0]
      num=196
      net_squeeze = tf.reduce_max(net, axis=3, keepdims=True)
      net_squeeze_flatten = tf.reshape(net_squeeze,[batch_size,1,1,num])
      net_squeeze_flatten=tf.layers.Flatten()(net_squeeze_flatten)
      net_l = tf.layers.dense(inputs=net_squeeze_flatten, units=int(num * reduction_ratio), name="net_l",
                                reuse=None, activation=tf.nn.relu)
      net_2 = tf.layers.dense(inputs=net_l, units=num, name="net_2", reuse=None)
      weight_feature=tf.reshape(net_2,[batch_size,14,14,1])
      weight_feature=tf.nn.sigmoid(weight_feature)

      net_new= net * weight_feature


      return net_new