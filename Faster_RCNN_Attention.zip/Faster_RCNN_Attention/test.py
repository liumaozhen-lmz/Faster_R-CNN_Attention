import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable

from modules import ConvOffset2d

num_deformable_groups = 2

N, inC, inH, inW = 1, 6, 512, 512
outC, outH, outW = 4, 512, 512
kH, kW = 3, 3

conv = nn.Conv2d(
    512,
    num_deformable_groups * 2 * 3 * 3,
    kernel_size=(3, 3),
    stride=(1, 1),
    padding=(1, 1),
    bias=False).cuda()

conv_offset2d = ConvOffset2d(
    512,
    512, (3, 3),
    stride=1,
    padding=1,
    num_deformable_groups=num_deformable_groups).cuda()


offset = conv(net)
output = conv_offset2d(net, offset)
output.backward(output.data)
print(output.size())
