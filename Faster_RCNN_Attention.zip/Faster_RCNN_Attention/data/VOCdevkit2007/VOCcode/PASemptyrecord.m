function record=PASemptyrecord
  record.imgname='';
  record.imgsize=[];
  record.database='';
  record.objects=PASemptyobject;
return