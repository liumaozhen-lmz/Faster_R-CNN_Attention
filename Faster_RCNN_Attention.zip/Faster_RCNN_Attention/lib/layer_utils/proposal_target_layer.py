# --------------------------------------------------------
# Faster R-CNN
# Copyright (c) 2015 Microsoft
# Licensed under The MIT License [see LICENSE for details]
# Written by Ross Girshick, Sean Bell and Xinlei Chen
# --------------------------------------------------------
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import numpy.random as npr
from lib.utils.cython_bbox import bbox_overlaps

from lib.config import config as cfg
from lib.utils.bbox_transform import bbox_transform


def proposal_target_layer(rpn_rois, rpn_scores, gt_boxes, _num_classes): #根据gt，对rpn产生的proposal打上分类标签以及计算回归的偏差
    """
    Assign object detection proposals to ground-truth targets. Produces proposal
    classification labels and bounding-box regression targets.
    """

    # Proposal ROIs (0, x1, y1, x2, y2) coming from RPN
    # (i.e., rpn.proposal_layer.ProposalLayer), or any other source
    all_rois = rpn_rois
    all_scores = rpn_scores

    # Include ground-truth boxes in the set of candidate rois
    if cfg.FLAGS.proposal_use_gt: # 在config里面这个参数是false，这段代码应该是不执行的
        zeros = np.zeros((gt_boxes.shape[0], 1), dtype=gt_boxes.dtype) # 按gt集合的形状生成个空数组，同样的行数
        all_rois = np.vstack( #首先把前面生成的0数组和gt数组叠加起来，然后再与roi数组堆叠起来
            (all_rois, np.hstack((zeros, gt_boxes[:, :-1])))
        )
        # not sure if it a wise appending, but anyway i am not using it
        all_scores = np.vstack((all_scores, zeros))

    num_images = 1
    rois_per_image = cfg.FLAGS.batch_size / num_images #TRAIN.BATCH_SIZE是感兴趣区域的数量，rois_per_image就是每一张图片允许的roi区域batch
    fg_rois_per_image = np.round(cfg.FLAGS.proposal_fg_fraction * rois_per_image) #按cfg.TRAIN.FG_FRACTION参数计算得到每一张图片的batch个roi中前景的数量

    # Sample rois with classification labels and bounding box regression
    # targets
    labels, rois, roi_scores, bbox_targets, bbox_inside_weights = _sample_rois( #_sample_rois函数，对每张图片的Batch按照参数设置随机采样
        all_rois, all_scores, gt_boxes, fg_rois_per_image,
        rois_per_image, _num_classes)

    rois = rois.reshape(-1, 5)
    roi_scores = roi_scores.reshape(-1)
    labels = labels.reshape(-1, 1)
    bbox_targets = bbox_targets.reshape(-1, _num_classes * 4)
    bbox_inside_weights = bbox_inside_weights.reshape(-1, _num_classes * 4)
    bbox_outside_weights = np.array(bbox_inside_weights > 0).astype(np.float32)

    return rois, roi_scores, labels, bbox_targets, bbox_inside_weights, bbox_outside_weights


def _get_bbox_regression_labels(bbox_target_data, num_classes):
    """Bounding-box regression targets (bbox_target_data) are stored in a
    compact form N x (class, tx, ty, tw, th)

    This function expands those targets into the 4-of-4*K representation used
    by the network (i.e. only one class has non-zero targets).

    Returns:
        bbox_target (ndarray): N x 4K blob of regression targets
        bbox_inside_weights (ndarray): N x 4K blob of loss weights
    """
    # bbox_target_data=N x (class, tx, ty, tw, th)，然后生成一个全0数组用于存放bbox_targets，然后生成一个全0数组用于存放bbox_targets，再计算
    clss = bbox_target_data[:, 0]
    bbox_targets = np.zeros((clss.size, 4 * num_classes), dtype=np.float32)
    bbox_inside_weights = np.zeros(bbox_targets.shape, dtype=np.float32)
    inds = np.where(clss > 0)[0] # 找出类别标号大于0的框，也就是找出前景的bbox
    for ind in inds:
        cls = clss[ind] # 首先提取出来类别标号
        start = int(4 * cls) # 类别标号扩大4倍数再加4.如果前景=1那么start=1 end=8
        end = start + 4
        bbox_targets[ind, start:end] = bbox_target_data[ind, 1:] # 如果是2的话，就是8-12。其实就是一个k类*4的向量，第一类的4个target在4-8之间，第二类在8-12之间，0类也就是背景在1-4之间
        bbox_inside_weights[ind, start:end] = cfg.FLAGS2["bbox_inside_weights"] # 对于不同类别的bbox，根据类别进行编码，编码到一个统一的向量里面，四个偏移所在的位置，是根据其所属类别来定位的
    return bbox_targets, bbox_inside_weights


def _compute_targets(ex_rois, gt_rois, labels):
    """Compute bounding-box regression targets for an image."""

    assert ex_rois.shape[0] == gt_rois.shape[0] # 计算bbox回归量
    assert ex_rois.shape[1] == 4
    assert gt_rois.shape[1] == 4

    targets = bbox_transform(ex_rois, gt_rois) # bbox_transform这个函数就是gt的四个坐标和extrect的roi四个坐标比对，然后转换出偏移
    if cfg.FLAGS.bbox_normalize_targets_precomputed:
        # Optionally normalize targets by a precomputed mean and stdev
        targets = ((targets - np.array(cfg.FLAGS2["bbox_normalize_means"]))
                   / np.array(cfg.FLAGS2["bbox_normalize_stds"]))
    return np.hstack(
        (labels[:, np.newaxis], targets)).astype(np.float32, copy=False)


def _sample_rois(all_rois, all_scores, gt_boxes, fg_rois_per_image, rois_per_image, num_classes):
    """Generate a random sample of RoIs comprising foreground and background
    examples.
    """
    # overlaps: (rois x gt_boxes)
    overlaps = bbox_overlaps(
        np.ascontiguousarray(all_rois[:, 1:5], dtype=np.float),
        np.ascontiguousarray(gt_boxes[:, :4], dtype=np.float))
    gt_assignment = overlaps.argmax(axis=1)
    max_overlaps = overlaps.max(axis=1)
    labels = gt_boxes[gt_assignment, 4] # 得到对应的gt之后，以gt的标签为label，放在第4位的原因是，前0-3四个位置放的是坐标

    # Select foreground RoIs as those with >= FG_THRESH overlap
    fg_inds = np.where(max_overlaps >= cfg.FLAGS.roi_fg_threshold)[0] # 定义前景
    # Guard against the case when an image has fewer than fg_rois_per_image
    # Select background RoIs as those within [BG_THRESH_LO, BG_THRESH_HI)
    bg_inds = np.where((max_overlaps < cfg.FLAGS.roi_bg_threshold_high) & # 定义背景，背景是一个范围，在参数里设置的是0.1~0.5
                       (max_overlaps >= cfg.FLAGS.roi_bg_threshold_low))[0]

    # Small modification to the original version where we ensure a fixed number of regions are sampled
    if fg_inds.size > 0 and bg_inds.size > 0: # 如果正样本很多，大于设置的batch*正样本比例，则随机采样，负样本就为batch减掉正样本
        fg_rois_per_image = min(fg_rois_per_image, fg_inds.size)
        fg_inds = npr.choice(fg_inds, size=int(fg_rois_per_image), replace=False)
        bg_rois_per_image = rois_per_image - fg_rois_per_image
        to_replace = bg_inds.size < bg_rois_per_image
        bg_inds = npr.choice(bg_inds, size=int(bg_rois_per_image), replace=to_replace)
    elif fg_inds.size > 0:
        to_replace = fg_inds.size < rois_per_image
        fg_inds = npr.choice(fg_inds, size=int(rois_per_image), replace=to_replace)
        fg_rois_per_image = rois_per_image
    elif bg_inds.size > 0:
        to_replace = bg_inds.size < rois_per_image
        bg_inds = npr.choice(bg_inds, size=int(rois_per_image), replace=to_replace)
        fg_rois_per_image = 0
    else:
        raise Exception()

    # The indices that we're selecting (both fg and bg)
    keep_inds = np.append(fg_inds, bg_inds) #最后挑选出来的前景和背景的索引
    # Select sampled values from various arrays:
    labels = labels[keep_inds] # 提取出对应的labels
    # Clamp labels for the background RoIs to 0
    labels[int(fg_rois_per_image):] = 0 # 又重复确定一边，25个框之后的全部设置为背景
    rois = all_rois[keep_inds]
    roi_scores = all_scores[keep_inds] # 提取出对应的roi以及得分

    bbox_target_data = _compute_targets( # 计算bbox偏移量
        rois[:, 1:5], gt_boxes[gt_assignment[keep_inds], :4], labels)
    # 根据偏移，进一步计算回归labels。实际是分为了两步计算。在这一步才有weight
    bbox_targets, bbox_inside_weights = \
        _get_bbox_regression_labels(bbox_target_data, num_classes)

    return labels, rois, roi_scores, bbox_targets, bbox_inside_weights
