from __future__ import absolute_import, division


import tensorflow as tf
from keras.layers import Conv2D
from keras.initializers import RandomNormal
from deform_conv.deform_conv import tf_batch_map_offsets


class ConvOffset2D(Conv2D):
    """ConvOffset2D"""

    def __init__(self, filters, init_normal_stddev=0.01, **kwargs):  #stddev-标准偏差，**kwargs打包关键字参数成dict给函数体调用
        self.filters = filters
        super(ConvOffset2D, self).__init__( #super().xxx调用父类，解决多重继承问题
            self.filters * 2, (3, 3), padding='same', use_bias=False,
            kernel_initializer=RandomNormal(0, init_normal_stddev),
            **kwargs
        )

    def call(self, x):
        """Return the deformed featured map"""

        # 获取x大小，x大小为（b,h,w,c)，分别为batch_size,图片高度，图片宽度，特征图大小

        x_shape = tf.shape(x) #原来是x.get_shape()

        x= Conv2D(512, (3, 3), padding='same', strides=(1, 1),name='feature_conv1', trainable=False)(x)
        x = Conv2D(512, (3, 3), padding='same', strides=(1, 1), name='feature_conv1', trainable=False)(x)
        # 调用普通卷积获得输出，输出结果为(b,h,w,2c)表示图片中每个像素需要偏移的量（x,y)
        offsets = super(ConvOffset2D, self).call(x)
        # reshape一下输出，方便后续操作，(b*c,h,w,2)表示共有b*c个图片，每个图片为h*w大小，每个像素对应2个方向
        # offsets: (b*c, h, w, 2)
        offsets = self._to_bc_h_w_2(offsets, x_shape)
        # 将原始输入也重新reshape一下方便后续操作
        # x: (b*c, h, w)
        x = self._to_bc_h_w(x, x_shape)
        # 调用deform_conv.py中的函数根据原始图片与偏移量生成新图片数据。
        # X_offset: (b*c, h, w)
        x_offset = tf_batch_map_offsets(x, offsets)
        # x_offset: (b, h, w, c)
        x_offset = self._to_b_h_w_c(x_offset, x_shape)
        return x_offset

    def compute_output_shape(self, input_shape):
        """Output shape is the same as input shape
        Because this layer does only the deformation part
        """
        return input_shape

    @staticmethod
    def _to_bc_h_w_2(x, x_shape):
        """(b, h, w, 2c) -> (b*c, h, w, 2)"""
        #x = tf.transpose(x, [0, 3, 1, 2])
        x = tf.reshape(x, (-1, x_shape[1], x_shape[2], 2))
        return x

    @staticmethod
    def _to_bc_h_w(x, x_shape):
        """(b, h, w, c) -> (b*c, h, w)"""
        #x = tf.transpose(x, [0, 3, 1, 2])
        x = tf.reshape(x, (-1, x_shape[1], x_shape[2]))
        return x

    @staticmethod
    def _to_b_h_w_c(x, x_shape):
        """(b*c, h, w) -> (b, h, w, c)"""
        x=tf.reshape(x,(-1,x_shape[1],x_shape[2],x_shape[3]))
    #   x = tf.reshape(
    #       x, (-1, x_shape[3], x_shape[1], x_shape[2])
    #  )
    #    x = tf.transpose(x, [0, 2, 3, 1])
        return x